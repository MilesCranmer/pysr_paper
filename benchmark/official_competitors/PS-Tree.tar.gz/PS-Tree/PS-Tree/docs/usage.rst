=====
Usage
=====

To use PSTree in a project::

    import pstree
