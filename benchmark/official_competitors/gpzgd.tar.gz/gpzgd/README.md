*Note from organizers*: this method is not officially competing due to late entry, but will be included in post-competition analysis as the project evolves.
