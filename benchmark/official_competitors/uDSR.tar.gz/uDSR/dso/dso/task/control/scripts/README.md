# Scripts

## benchmark_zoo.py

Generates benchmark results for given algotrithm/environment pairs and writes them to `benchmark_zoo_results.csv`.

## policy_eval.py

Also generates benchmarks but allows more control over the output during episodes. This can be used to debug policies and environments. Results are saved to `policy_eval_results.csv`.