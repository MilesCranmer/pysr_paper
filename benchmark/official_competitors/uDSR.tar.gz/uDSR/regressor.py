import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent / "dso"))
from dso import ParallelizedUnifiedDeepSymbolicRegressor

est = ParallelizedUnifiedDeepSymbolicRegressor()

def format_expr(expr, X=None):
    if X is None or not hasattr(X, 'columns'):
        return expr

    features = X.columns

    for i in reversed(range(len(features))):
        before = "x{}".format(i + 1)
        after = "INPUT_{}_TUPNI".format(i)
        expr = expr.replace(before, after)

    for i, feature in enumerate(features):
        before = "INPUT_{}_TUPNI".format(i)
        after = feature
        expr = expr.replace(before, after)

    return expr


def model(est, X=None):
    expr = str(est.expr)
    return format_expr(expr, X=X)

def models(est, X=None):
    exprs = [
        str(est.pareto[complexity]["expr"])
        for complexity in range(1000)
        if complexity in est.pareto
    ]
    exprs = [format_expr(e, X=X) for e in exprs]
    return exprs


eval_kwargs = {
    "test_params": {"max_time": 10},
}
