export LD_LIBRARY_PATH=/mnt/home/mcranmer/ceph/miniforge3/envs/Bingo/lib:$LD_LIBRARY_PATH
