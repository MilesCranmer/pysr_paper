"""Top-level package for PSTree."""

__author__ = """Hengzhe Zhang"""
__email__ = 'zhenlingcn@foxmail.com'
__version__ = '0.1.0'
