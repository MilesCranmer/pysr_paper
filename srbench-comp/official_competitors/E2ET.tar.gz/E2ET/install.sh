#install sympytorch
#git clone https://github.com/pakamienny/sympytorch.git
pip install git+https://github.com/pakamienny/sympytorch.git@rationals

#wget -nc https://dl.fbaipublicfiles.com/symbolicregression/model1.pt

pip install git+https://github.com/pakamienny/e2e_transformer.git
